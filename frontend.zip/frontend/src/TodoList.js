import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TodoList = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [deletingId, setDeletingId] = useState(null);

  // Fetch tasks from backend
  useEffect(() => {
    axios
      .get('http://65.0.30.1:5000/todos')
      .then((response) => setTasks(response.data))
      .catch((error) => console.error('Error fetching tasks:', error));
  }, []);

  // Add a new task
  const addTask = (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;

    axios
      .post('http://65.0.30.1:5000/todos', { task: newTask })
      .then((response) => {
        // Directly updating state with previous tasks plus the new one
        setTasks((prevTasks) => [...prevTasks, response.data]);
        setNewTask(''); // Clear the input field
      })
      .catch((error) => {
        console.error('Error adding task:', error);
      });
  };

  // Delete a task
  const deleteTask = (id) => {
    setDeletingId(id); // Temporarily mark as deleting
    axios
      .delete(`http://65.0.30.1:5000/todos/${id}`)
      .then(() => {
        setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
        setDeletingId(null); // Reset deleting state
      })
      .catch((error) => {
        console.error('Error deleting task:', error);
        setDeletingId(null); // Reset deleting state on error
      });
  };

  return (
    <div className="todo-list">
      <form onSubmit={addTask} className="form">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Enter a new task"
          className="input"
        />
        <button type="submit" className="add-btn">
          Add
        </button>
      </form>

      <ul className="task-list">
        {tasks.map((task) => (
          <li key={task.id} className="task-item">
            <span>{task.task}</span>
            <button
              onClick={() => deleteTask(task.id)}
              className="delete-btn"
              disabled={deletingId === task.id}
            >
              {deletingId === task.id ? 'Deleting...' : 'Delete'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
