import React, { useState } from 'react';
import axios from 'axios';

const AddTask = ({ getTasks }) => {
  const [task, setTask] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (task.trim()) {
      axios.post('http://65.0.30.1:5000/todos', { task })
        .then(() => {
          getTasks();  // Refresh tasks after adding
          setTask('');  // Clear the input field
        })
        .catch(error => console.error('Error adding task:', error));
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input 
        type="text" 
        value={task} 
        onChange={(e) => setTask(e.target.value)} 
        placeholder="Enter a new task" 
        required 
      />
      <button type="submit">Add Task</button>
    </form>
  );
};

export default AddTask;
